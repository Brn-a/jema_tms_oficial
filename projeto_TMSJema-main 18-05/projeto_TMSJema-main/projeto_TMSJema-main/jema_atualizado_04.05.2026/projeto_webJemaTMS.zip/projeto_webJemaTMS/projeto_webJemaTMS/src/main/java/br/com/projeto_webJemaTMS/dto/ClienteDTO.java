package br.com.projeto_webJemaTMS.dto;

public class ClienteDTO {

}

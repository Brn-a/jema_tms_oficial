package br.com.projeto_webJemaTMS.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "nota_fiscal")
public class Nf {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Integer numero;

    private Double volume;
    private Double peso;

    private String quemRecebe;

    private Double valorFinal;
    private Double valorFrete;

    // Cliente (muitas NFs para 1 cliente)
    @ManyToOne
    @JoinColumn(name = "fk_cliente")
    private Cliente cliente;

    // Lista de produtos da NF
    @OneToMany(mappedBy = "notaFiscal", cascade = CascadeType.ALL)
    private List<ItemNota> itens;

    public Nf() {
    }

    public Nf(Long id, Integer numero, Double volume, Double peso,
                      String quemRecebe, Double valorFinal, Double valorFrete,
                      Cliente cliente) {
        this.id = id;
        this.numero = numero;
        this.volume = volume;
        this.peso = peso;
        this.quemRecebe = quemRecebe;
        this.valorFinal = valorFinal;
        this.valorFrete = valorFrete;
        this.cliente = cliente;
    }

}
